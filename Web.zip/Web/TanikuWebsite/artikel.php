<!DOCTYPE HTML>  
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/custom.css">
</head>
<body>  
<center>
<?php
// define variables and set to empty values
  require 'vendor/autoload.php';
 $collection = (new MongoDB\Client("mongodb://127.0.0.1:27017"))->taniku->taniku;

if (isset($_POST['submit'])){
  $insertOneResult = $collection->insertOne([
    'penyakit' => $_POST['penyakit'],
    'deskripsi' => $_POST['deskripsi'],
    'tips' => $_POST['tips']
]);
}

?>

<h2>Artikel</h2>
<form method="post">  
  Nama Penyakit: <br/><input type="text" name="penyakit">
  <br><br>
  Deskripsi: <br/><textarea name="deskripsi" rows="5" cols="40"></textarea>
  <br><br>
   <br>
  Tips Kesehatan: <br/><textarea name="tips" rows="5" cols="40"></textarea>
  <br><br>
  <input type="submit" name="submit" value="Submit">  
  <br><br> 
</form>
</center>
</body>
</html>