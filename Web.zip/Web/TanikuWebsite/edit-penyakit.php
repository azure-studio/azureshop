<?php
header("location: artikel.php");
?>