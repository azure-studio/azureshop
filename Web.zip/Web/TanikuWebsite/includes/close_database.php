<?php
	include($_SERVER['DOCUMENT_ROOT'].'/tanikuwebsite/includes/variables.php');
	$connect->close();
?>