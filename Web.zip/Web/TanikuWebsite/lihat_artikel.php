<html>
<head>
  <title>Artikel | Taniku</title>
</head>
<body>

<center>
<table  border='1' Width='800'>  
<tr>
    <th> Penyakit </th>
    <th> Deskripsi </th>
    <th> Tips </th>
    <th colspan="3"> Action </th>
    
</tr>
<center>

<?php
 require 'vendor/autoload.php';
 $collection = (new MongoDB\Client())->taniku->taniku;
$cursor = $collection->find();
foreach ($cursor as $data1) {
    $data[]=$data1;
    }
    $a=0;
while (@$data[$a]){
    echo "    
        <tr>
        <td>".$data[$a]['penyakit']."</td>
        <td>".$data[$a]['deskripsi']."</td>
        <td>".$data[$a]['tips']."</td>
        <td><a href='edit-penyakit.php?penyakit=".$data[$a]['penyakit']."'>Edit</a></td>
        <td><a href='delete-penyakit.php?penyakit=".$data[$a]['penyakit']."'>Delete</a></td>
        <td><a href='lihat_artikel_android.php'>Lihat</a></td>
        </tr> 
        ";
        $a++;
        
}


?>

</table>
</body>
</html>