<html>
<head>
  <title>Artikel | Taniku</title>
</head>
<body>

<center>
<table  border='1' Width='800'> 
<h1>Artikel Kesehatan Dunia Pertanian | Taniku </h1>
<tr>
    <th> Penyakit </th>
    <th> Deskripsi </th>
    <th> Tips </th>
    
</tr>
<center>

<?php
 require 'vendor/autoload.php';
 $collection = (new MongoDB\Client())->taniku->taniku;
$cursor = $collection->find();
foreach ($cursor as $data1) {
    $data[]=$data1;
    }
    $a=0;
while (@$data[$a]){
    echo "    
        <tr>
        <td>".$data[$a]['penyakit']."</td>
        <td>".$data[$a]['deskripsi']."</td>
        <td>".$data[$a]['tips']."</td>
        </tr> 
        ";
        $a++;
        
}


?>

</table>
</body>
</html>