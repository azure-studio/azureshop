<?php
   echo $_GET['penyakit'];
   echo "<br />";
   echo $_GET['deskripsi'];
   echo "<br />";
   echo $_GET['tips'];
?>