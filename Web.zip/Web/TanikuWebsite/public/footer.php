<?php include('includes/variables.php'); ?>
<div id="footer">
</div>